# AeroGuard

**Explainable Airport Disruption Decision Assistant**  
HackSHSID 2026 · Track 3 · Fictional simulation prototype

> **Safety notice:** This project operates entirely on organizer-generated simulated aviation data. It has no real flight-control capabilities and is unsuitable for live airline decisions. All risk assessments are advisory, and every safety, flight, cancellation, dispatch, maintenance, compensation and passenger publication decision belongs to qualified professionals.

## Start the demo in 10 seconds

1. Download or clone this repository.
2. Open **`index.html`** in any modern web browser.
3. Choose one of five provided events, or choose **NEW** to create an unseen incident.
4. Select an airport, change conditions and choose **Analyze incident**.
5. Explore the linked evidence, risk, information gaps, response plan and audience-specific drafts.
6. Try **Human-in-the-loop review** and export the session audit JSON.

The user interface and analysis engine are embedded inside `index.html`. **No Python server, external JavaScript, API key, internet connection or JSON fetch is required.** The app can also be hosted on a static site such as GitHub Pages.

## What this prototype does

- Covers eight fictional airports with 192 simulated monthly operating observations across 2024–2025.
- Establishes each airport's 2025 baseline from twelve monthly scheduled-completion fractions.
- Handles weather risk, operating pressure, source contradictions, poor evidence and human feedback.
- Reports **Low, Medium, High or Indeterminate** triage recommendations with an explanation and source IDs.
- Compares a new measured rate with history only when the same metric, denominator and monthly reporting period have been explicitly verified.
- Produces separate internal operations, airport coordination and passenger draft messages.
- Exports the original recommendation and any subsequent reviewer feedback in a downloadable browser-session JSON audit.

The engine is a **transparent deterministic rule-based decision-support system**. It does not use a connected generative LLM, a live aviation feed or a forecast model. Its ability to handle new combinations of supported inputs should not be mistaken for unconstrained natural-language understanding or validated prediction accuracy.

## Reproduce the tests

With Node.js 18 or newer installed, from the repository root:

```sh
node tests/run_tests.mjs
node src/build.mjs
node tests/ui_smoke.mjs
```

The suite includes 15 organizer-aligned checks and 24 additional adversarial/boundary checks. The submitted version passes **39/39 functional checks**, plus a JavaScript/DOM smoke test of the self-contained HTML. These are developer-authored functional tests, **not** independent aviation-domain accuracy or safety certification.

To rebuild the frozen simulated data snapshot, install Python and `openpyxl`, then run:

```sh
python src/build_data.py
```

This reads `source/Track3_Data_original.xlsx`, validates row counts and input ranges, and creates `data/simulation.json`. It never fetches real-world data.

## Repository layout

| Path | Purpose |
| --- | --- |
| `index.html` | Complete offline interactive demo |
| `src/engine.js` | Pure decision/risk engine; human and safety boundaries |
| `src/app.js` | User interface, data chart and JSON audit export |
| `src/index.template.html` | Source HTML template with responsive styling |
| `src/build.mjs` | Bundles the three components with simulation data into `index.html` |
| `src/build_data.py` | Auditable extraction from organizer source workbook |
| `data/simulation.json` | Fictional, English-labeled data snapshot |
| `data/event_outputs.json` | Reproducible decisions for the five organizer events |
| `data/test_summary.json` | Full functional-check log |
| `tests/run_tests.mjs` | 39 rule, data integrity and boundary tests |
| `tests/ui_smoke.mjs` | Standalone HTML initialization and interaction smoke test |
| `docs/Technical_Report.pdf` | Methods, outcomes, risk card, test analysis and implementation roadmap |
| `docs/Client_Presentation.pptx` | Client-facing 10-slide presentation |
| `docs/Completed_Track3_English.xlsx` | English data, formulas, decisions, rules, tests and feedback |
| `assets/AeroGuard_Thumbnail.png` | English project gallery cover image, under 5 MB |
| `source/` | Unmodified organizer workbook and problem statement |
| `SUBMISSION_TEXT.md` | Ready-to-edit text for the HackSHSID form |

## Evaluation boundaries

The self-tests show only that the programmed logic behaves as designed for listed cases. The project **has not** established forecast precision, field robustness, reduction of flight delays or measurable business value. It does not implement source authentication, private-data safeguards or an airline-grade audit platform. Human labeling of new scenarios and controlled shadow operation are proposed next steps, not completed activities.

Do not submit real passenger or employee identifiers into the demo. Basic email and phone-like patterns are rejected, but this is not a production-grade privacy filter.
