/** Deterministic functional and adversarial tests; no safety or prediction certification. */
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const data = JSON.parse(await fs.readFile(path.join(root,'data/simulation.json'),'utf8'));
const source = await fs.readFile(path.join(root,'src/engine.js'),'utf8');
const scope={}; vm.runInNewContext(source,scope);
const engine=scope.AeroGuardEngine;
const cases=[];
const base=(rest={})=>({id:'NEW',name:'Test case',airport:'Hailing International Airport',time:'Test T0',weather:'',operations:'',unknowns:'Flight-specific status and ground capacity',weatherRisk:'None',pressure:'None',sourceStatus:'Unknown',independentSources:1,conflict:false,safetyConcern:false,currentRate:null,comparableRateVerified:false,officialStatusVerified:false,...rest});
const evalCase=(rest={},feedback=null)=>engine.analyze(base(rest),data,feedback);
function check(id,label,test){try{test();cases.push({id,label,pass:true})}catch(e){cases.push({id,label,pass:false,error:e.message})}}
const evt = id => {const o=data.events.find(e=>e.id===id);return base({...o,name:o.name,weatherRisk:o.weatherRisk,pressure:o.pressure,conflict:o.conflict,independentSources:o.independentSources});};

// 15 organizer-aligned contract tests
check('TEST001','No unverified certain flight delay',()=>assert.match(evalCase({weatherRisk:'High'}).messages.passengers,/does not establish any delay or cancellation/));
check('TEST002','Evidence has source IDs',()=>assert.ok(evalCase().facts.every(f=>f.source)));
check('TEST003','Conflicting data suspends conclusion',()=>assert.equal(engine.analyze(evt('EVT003'),data).risk,'Indeterminate'));
check('TEST004','No unsupported weather causality',()=>assert.match(evalCase({weatherRisk:'High'}).assumptions.join(' '),/not been established/));
check('TEST005','Cancellation stays under human authority',()=>assert.match(evalCase().humanOnly,/cancellation/));
check('TEST006','Audience-specific messages differ',()=>{const x=evalCase();assert.notEqual(x.messages.operations,x.messages.airport);assert.notEqual(x.messages.airport,x.messages.passengers)});
check('TEST007','Previously unseen incident can be evaluated',()=>assert.equal(evalCase({name:'Unseen incident',airport:'Linjiang Airport',weatherRisk:'Medium'}).risk,'Medium'));
check('TEST008','Unknown aircraft state is retained',()=>assert.ok(evalCase({unknowns:'Unknown inbound aircraft positions'}).gaps.includes('Unknown inbound aircraft positions')));
check('TEST009','Simulation clearly labeled',()=>assert.match(evalCase().messages.operations,/SIMULATION/));
check('TEST010','Reviewer rejection retained',()=>assert.equal(evalCase({}, {decision:'rejected',reason:'Resources unknown'}).review.decision,'rejected'));
check('TEST011','Personal information rejected',()=>assert.equal(evalCase({weather:'Contact alice@example.com'}).ok,false));
check('TEST012','Passenger draft always requires review',()=>assert.match(evalCase().messages.passengers,/NOT APPROVED FOR PUBLICATION/));
check('TEST013','Reviewer evidence changes a high alert',()=>{const i={weatherRisk:'High',pressure:'High',independentSources:2};assert.equal(evalCase(i).risk,'High');assert.equal(evalCase(i,{decision:'rejected',reason:'Verified resources',resourcesVerified:true}).risk,'Medium')});
check('TEST014','Historical time window explicit',()=>assert.ok(evalCase().facts.some(f=>f.statement.includes('2025 monthly completion baseline'))));
check('TEST015','Unreliable sources invoke stop rule',()=>{const x=evalCase({sourceStatus:'Unreliable'});assert.equal(x.risk,'Indeterminate');assert.ok(x.rules.includes('RULE012'))});

// Additional boundary and negative-path checks
check('ADV001','All eight airports have 12 comparable baseline months',()=>assert.equal(data.airports.filter(a=>a.baseline_n===12).length,8));
check('ADV002','Historical means recompute from actual monthly series',()=>{for(const a of data.airports){const mean=a.monthly_2025.reduce((sum,x)=>sum+x.completed,0)/12;assert.ok(Math.abs(mean-a.baseline_mean)<1e-6)}});
check('ADV003','Known synthetic source conflict cannot be cleared by favorable weather',()=>assert.equal(evalCase({conflict:true,weatherRisk:'None',pressure:'None'}).risk,'Indeterminate'));
check('ADV004','Unknown airport does not inherit a different baseline',()=>assert.equal(evalCase({airport:'Another Airport'}).risk,'Indeterminate'));
check('ADV005','Unverified present rate must not be compared with history',()=>{const r=evalCase({currentRate:0.05,comparableRateVerified:false});assert.equal(r.calculation.deviationPp,null);assert.equal(r.risk,'Low')});
check('ADV006','Verified comparable 5pp decline triggers review but does not assert weather cause',()=>{const b=data.airports[1].baseline_mean;const x=evalCase({airport:data.airports[1].name,currentRate:b-0.060,comparableRateVerified:true});assert.equal(x.risk,'Medium');assert.ok(x.rules.includes('RULE003'))});
check('ADV007','Verified decrease plus hazard can generate high risk',()=>{const b=data.airports[1].baseline_mean;assert.equal(evalCase({airport:data.airports[1].name,currentRate:b-0.060,comparableRateVerified:true,weatherRisk:'High'}).risk,'High')});
check('ADV008','Exactly 5pp decline does not trigger greater-than-5 branch',()=>{const b=data.airports[1].baseline_mean;assert.equal(evalCase({airport:data.airports[1].name,currentRate:Number((b-.05).toFixed(6)),comparableRateVerified:true}).risk,'Low')});
check('ADV009','Impossible fraction rejected',()=>assert.equal(evalCase({currentRate:1.5}).ok,false));
check('ADV010','Negative fraction rejected',()=>assert.equal(evalCase({currentRate:-.2}).ok,false));
check('ADV011','Zero fraction is a valid bounded input',()=>assert.equal(evalCase({currentRate:0,comparableRateVerified:true}).ok,true));
check('ADV012','Unknown weather enum rejected',()=>assert.equal(evalCase({weatherRisk:'Extreme'}).ok,false));
check('ADV013','Uncorroborated compound warning remains medium',()=>assert.equal(evalCase({weatherRisk:'High',pressure:'High',independentSources:1}).risk,'Medium'));
check('ADV014','Two independently verified compound signals can be high',()=>assert.equal(evalCase({weatherRisk:'High',pressure:'High',independentSources:2}).risk,'High'));
check('ADV015','Safety concern forces indeterminate human escalation',()=>{const x=evalCase({safetyConcern:true,weatherRisk:'High'});assert.equal(x.risk,'Indeterminate');assert.match(x.escalation,/safety/i)});
check('ADV016','Rejection without evidence does not silently lower alert to low',()=>assert.equal(evalCase({weatherRisk:'High'}, {decision:'rejected',reason:'Disagree',resourcesVerified:false}).risk,'Indeterminate'));
check('ADV017','Human review never clears source conflict',()=>assert.equal(evalCase({conflict:true},{decision:'rejected',reason:'Adequate resources',resourcesVerified:true}).risk,'Indeterminate'));
check('ADV018','Human review never clears safety stop',()=>assert.equal(evalCase({safetyConcern:true},{decision:'rejected',reason:'Adequate resources',resourcesVerified:true}).risk,'Indeterminate'));
check('ADV019','Accepting a recommendation preserves risk',()=>{const x=evalCase({weatherRisk:'Medium'});const y=evalCase({weatherRisk:'Medium'},{decision:'accepted',reason:'Reviewed'});assert.equal(y.risk,x.risk)});
check('ADV020','Email in input is blocked',()=>assert.equal(evalCase({operations:'Employee email test@example.org'}).ok,false));
check('ADV021','Phone-like input is blocked',()=>assert.equal(evalCase({operations:'Call +1 415 555 1234'}).ok,false));
check('ADV022','Adverse historical weather missing values are disclosed',()=>assert.ok(evalCase({airport:'Hailing International Airport'}).gaps.some(x=>x.includes('historical monthly weather'))));
check('ADV023','Outputs do not contain a passenger-specific arrival time',()=>assert.doesNotMatch(evalCase({weatherRisk:'High'}).messages.passengers,/arrive at \d/));
check('ADV024','Every rule identifier maps to organizer rulebook range',()=>{for(const rule of evalCase({weatherRisk:'High',pressure:'High',independentSources:2}).rules)assert.match(rule,/^RULE0(0[1-9]|1[0-2])$/)});

const passed=cases.filter(t=>t.pass).length;
const summary={total:cases.length,passed,description:`${passed}/${cases.length} deterministic checks passed: 15 organizer-aligned rules and ${cases.length-15} adversarial/boundary checks. No independent operational validation.`,cases};
await fs.writeFile(path.join(root,'data/test_summary.json'),JSON.stringify(summary,null,2)+'\n');
const scenarios=Object.fromEntries(data.events.map(e=>[e.id,engine.analyze(evt(e.id),data)]));
await fs.writeFile(path.join(root,'data/event_outputs.json'),JSON.stringify(scenarios,null,2)+'\n');
for(const c of cases)console.log(`${c.pass?'PASS':'FAIL'} ${c.id} ${c.label}${c.error?' | '+c.error:''}`);
console.log(`Summary: ${passed}/${cases.length}`);
if(passed!==cases.length)process.exitCode=1;
