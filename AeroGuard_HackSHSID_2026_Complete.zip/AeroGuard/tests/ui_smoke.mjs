/** No-browser JavaScript/DOM smoke test for the self-contained HTML asset. */
import fs from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const html=await fs.readFile(new URL('../index.html',import.meta.url),'utf8');
const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]);
assert.equal(scripts.length,3);
assert.doesNotMatch(scripts.join('\n'),/\bfetch\s*\(/);
class Elem {
  constructor(tag='div',id=''){this.tag=tag;this.id=id;this.value='';this.checked=false;this.textContent='';this.style={};this.className='';this.children=[];this.attributes={};this.listeners={};this.href='';this.download='';}
  appendChild(x){this.children.push(x);if(this.tag==='select'&&!this.value)this.value=x.value;return x}
  removeChild(x){const i=this.children.indexOf(x);if(i>=0)this.children.splice(i,1);return x}
  get firstChild(){return this.children[0]||null}
  addEventListener(event,cb){this.listeners[event]=cb}
  dispatch(event){this.listeners[event]?.()}
  setAttribute(k,v){this.attributes[k]=v}
  remove(){}
  click(){}
}
const nodes={};const get=id=>nodes[id]||(nodes[id]=new Elem('div',id));
for(const id of ['scenario','airport','weatherRisk','pressure','sourceStatus','independentSources','reviewDecision'])get(id).tag='select';
const ctx={window:{},document:{getElementById:get,createElement:tag=>new Elem(tag),createElementNS:(ns,tag)=>new Elem(tag),body:new Elem('body')},Date,Number,String,Math,JSON,Set,Blob:class{},URL:{createObjectURL:()=>'',revokeObjectURL(){}},console};
for(const source of scripts)vm.runInNewContext(source,ctx,{timeout:10000});
assert.equal(get('scenario').children.length,6);
assert.equal(get('airport').children.length,8);
assert.equal(get('riskValue').textContent,'Medium');
get('scenario').value='EVT003';get('scenario').dispatch('change');
assert.equal(get('riskValue').textContent,'Indeterminate');
get('scenario').value='NEW';get('scenario').dispatch('change');
get('airport').value='Linjiang Airport';get('airport').dispatch('change');
get('weatherRisk').value='High';get('pressure').value='High';get('independentSources').value='2';get('sourceStatus').value='Verified';
get('incidentName').value='Unseen compound stress';get('weather').value='Rain and gusts';get('operations').value='Declining completed flights';
get('analyze').dispatch('click');
assert.equal(get('riskValue').textContent,'High');
assert.match(get('decisionText').textContent,/high-risk escalation/i);
get('pressure').value='None';get('independentSources').value='1';get('currentRate').value='0.71';get('analyze').dispatch('click');
assert.equal(get('riskValue').textContent,'Medium');
assert.match(get('calcNote').textContent,/No numeric anomaly claim/);
get('comparableRateVerified').checked=true;get('analyze').dispatch('click');
assert.equal(get('riskValue').textContent,'High');
get('reviewDecision').value='rejected';get('reviewReason').value='Verified ground equipment availability';get('resourcesVerified').checked=true;get('applyReview').dispatch('click');
assert.equal(get('riskValue').textContent,'Medium');
assert.match(get('reviewBanner').textContent,/Original risk: High/);
get('reviewReason').value='';get('applyReview').dispatch('click');
assert.match(get('errors').textContent,/reason is required/);
get('reviewReason').value='Reviewed';get('weather').value='Contact test@example.com';get('analyze').dispatch('click');
assert.match(get('errors').textContent,/Email addresses are not permitted/);
console.log(JSON.stringify({result:'PASS',htmlScripts:scripts.length,scenarioOptions:6,airportOptions:8,checks:['no network dependency','initial screen','source conflict','unseen event','new airport','rate comparability gate','high risk escalation','human feedback','missing review reason','PII block','rendered SVG history'],svgElements:get('historyChart').children.length}));
