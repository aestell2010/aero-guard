"""Generate the English project evidence report from reproducible simulation results."""
import json
from pathlib import Path
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'data/simulation.json').read_text())
RESULTS=json.loads((ROOT/'data/event_outputs.json').read_text())
TESTS=json.loads((ROOT/'data/test_summary.json').read_text())
OUT=ROOT/'docs/Technical_Report.pdf'
NAVY=colors.HexColor('#102B4C'); BLUE=colors.HexColor('#17679F'); P=colors.HexColor('#EDF4FA'); GREY=colors.HexColor('#526B82')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='CoverTitle',fontName='Helvetica-Bold',fontSize=25,leading=30,textColor=NAVY,spaceAfter=11))
styles.add(ParagraphStyle(name='Lead',fontName='Helvetica',fontSize=10.7,leading=16,textColor=BLUE,spaceAfter=12))
styles.add(ParagraphStyle(name='H2x',fontName='Helvetica-Bold',fontSize=15,leading=20,textColor=NAVY,spaceBefore=15,spaceAfter=9))
styles.add(ParagraphStyle(name='Textx',fontName='Helvetica',fontSize=9,leading=13.4,spaceAfter=8))
styles.add(ParagraphStyle(name='Smallx',fontName='Helvetica',fontSize=7.5,leading=10,spaceAfter=4))
doc=SimpleDocTemplate(str(OUT),pagesize=(612,792),leftMargin=47,rightMargin=47,topMargin=48,bottomMargin=50)
S=[]
def p(t,sty='Textx'):S.append(Paragraph(t,styles[sty]))
def h(t):p(t,'H2x')
def table(rows,widths):
  vals=[[Paragraph(str(v),ParagraphStyle(f'h{i}',parent=styles['Smallx'],textColor=colors.white,fontName='Helvetica-Bold')) if ridx==0 else Paragraph(str(v),styles['Smallx']) for i,v in enumerate(r)] for ridx,r in enumerate(rows)]
  t=Table(vals,colWidths=widths,repeatRows=1,hAlign='LEFT')
  t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,P]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,-1),(-1,-1),.6,colors.HexColor('#D1E0ED'))]))
  S.append(t)
def footer(c,doc):
  c.setStrokeColor(colors.HexColor('#C6D5E3'));c.line(47,39,565,39)
  c.setFont('Helvetica',7.5);c.setFillColor(GREY)
  c.drawString(47,27,'AEROGUARD | HACKSHSID TRACK 3 | FICTIONAL SIMULATION ONLY')
  c.drawRightString(565,27,str(doc.page))

p('AEROGUARD','Lead')
p('Explainable Airport Disruption Decision Support','CoverTitle')
p('HackSHSID 2026 | Track 3 | Technical report and evidence dossier','Lead')
banner=ROOT/'assets/AeroGuard_Thumbnail.png'
S.append(Image(str(banner),width=514,height=288))
S.append(Spacer(1,16))
p('<b>Executive summary.</b> AeroGuard is a standalone, offline-ready assistant that evaluates organizer-simulated airport incidents. It combines 2025 airport-specific completion histories, explicit event risk inputs, source reliability checks and a traceable operational rulebook. It offers prioritized verification steps and separate draft messages for operations staff, airport teams and passengers. It never executes flight or publication decisions.')
p(f"<b>What is implemented:</b> 8 fictional airports, 192 operating-month records, five original incidents, user-entered unseen scenarios, human review with an audit export and {TESTS['passed']}/{TESTS['total']} passing deterministic checks. <b>What has not been established:</b> independent aviation safety, forecast accuracy, live operational value, or production-grade privacy and authentication.")
S.append(PageBreak())

h('1. Problem framing and decision boundaries')
p('The airline needs to recognize potential disruptions when weather or airport capacity changes, decide what information to verify first, and coordinate updates without inventing flight outcomes. The prototype is strictly a decision-support demonstrator. Final flight release, safety, cancellation, dispatch, maintenance, compensation and passenger publication decisions remain with qualified staff.')
p('For each event, the engine reports a risk tier (Low / Medium / High / Indeterminate), confidence qualifier, verified or user-provided facts with source IDs, hypotheses, unknowns, ordered checks, a trigger for human escalation, and three audience-specific communication drafts. Its high-risk level is a triage suggestion and has no regulatory or safety certification meaning.')
h('2. Source data and baselines')
p('Organizer-provided simulation includes 8 airports, 24 months of monthly scheduled-completion fractions and weather records for 2024-2025, plus 2024-2025 annual scale statistics. The analysis uses the unweighted average of the 12 monthly scheduled-completion fractions in 2025 for each airport. Departure punctuality is a separate metric and is not substituted.')
table([['Fictional airport','2025 monthly mean','Monthly SD','2025 passengers (10,000s)']]+[[a['name'],f"{a['baseline_mean']:.2%}",f"{a['baseline_sd_pp']:.2f} pp",a['passengers_10k']] for a in DATA['airports']],[207,100,84,127])
p('<b>Data quality:</b> Four monthly weather records contain missing values, EVT003 deliberately presents conflicting reports, and Hailing July-August 2025 includes organizer-designed anomalies. The evidence is fictional, so a detected pattern is not empirical evidence about a real airport.')
S.append(PageBreak())

h('3. Explainable risk policy')
table([['Input or condition','System response'],
 ['Historical context','Display local 2025 12-month unweighted mean and monthly range; retain source SIM-BASE'],
 ['Weather / operating pressure','Set a provisional Medium watch and produce checks; no claim that a particular flight is delayed'],
 ['Comparable current completion rate','Only compute percentage-point difference after explicit verification of the same metric, denominator and monthly window'],
 ['Verified decline greater than 5 percentage points','Request anomaly confirmation; High only when a separate weather or operations warning exists'],
 ['High weather + High operating pressure + 2 verified independent sources','High-risk escalation recommendation; requires human review'],
 ['Conflicting/unreliable sources, missing airport history, safety concern','Indeterminate; stop firm conclusions and identify escalation owner'],
 ['Human reviewer rejection','Preserve original risk and reason; reassess. Without supporting evidence, hold the conclusion']], [210,308])
p('The 5 percentage-point trigger comes from organizer rule RULE003. It is not tuned on independent event labels. Subtracting an hourly rate from a historical monthly rate without matching the measurement definition would create spurious precision; the new prototype explicitly prevents this.')
h('4. Evidence chain')
p('All result fields originate from event inputs (SIM-EVENT), local historical data (SIM-BASE), annual business size data (SIM-SCALE), or the 12 organizer operating rules (RULE001-RULE012). The browser bundle contains the complete relevant synthetic dataset. No live meteorological feed, external LLM, airline API, passenger list, or flight plan integration is used.')
p('The rules are deterministic and auditable. They can process previously unseen combinations of supported inputs, but free-text aviation understanding is limited. Human-defined weather and operations severity categories should not be confused with independent AI measurement or predictive certainty.')
S.append(PageBreak())

h('5. Five organizer event evaluations')
notes={
 'EVT001':'Weather warning and concentrated schedule. Verify current forecast, airport capacity and downstream rotations. No confirmed delay.',
 'EVT002':'Prior completion decline and gate pressure. Check denominator, gates and inbound aircraft; weather causation unproven.',
 'EVT003':'Source conflict with a 40-minute update gap. Indeterminate until definitions and timestamps are reconciled.',
 'EVT004':'Thunderstorm forecast without formal delay. Passenger message remains a cautious, human-approved draft.',
 'EVT005':'Human rejection demonstration. Resource information must be verified and original advice preserved.'}
table([['Event','Result','Explanation']]+[[e['id'],RESULTS[e['id']]['risk'],notes[e['id']]] for e in DATA['events']],[63,97,358])
p('The EVT005 feedback in the original organizer workbook is an illustrative scenario, not an interview carried out by this project. The interactive assistant allows a reviewer to accept, modify or reject recommendations and export the original assessment and revised decision as a JSON session audit.')
h('6. User-facing demonstration')
p('Open index.html directly in Safari, Chrome or another modern browser. All five organizer incidents and eight airports are available without a server or file fetch. A sixth option supports a new incident. Changing scenario or airport triggers a fresh assessment. Users can edit signals and texts, validate comparable current rates, force source-conflict and safety-stop cases, submit a review, and export a session audit.')
p('The entire HTML includes data, rendering logic and the decision engine. Source engine.js and index.template.html are also provided to support code review, while tests verify the shipped bundle without network dependencies.')
S.append(PageBreak())

h('7. Functional and boundary test evidence')
p(f"<b>Automated checks: {TESTS['passed']}/{TESTS['total']} passed.</b> The suite includes 15 organizer-aligned behavior checks plus {TESTS['total']-15} additional adverse-input, numeric boundary, evidence-gap and human-review tests. These are deterministic implementation checks written with the prototype. The score is not an external evaluation or a real operational success rate.")
table([['Test group','Coverage','Pass count'],
 ['Organizer-aligned 15','Source conflict, missing information, traceability, human authority, stakeholder wording, new incident, feedback, privacy and stop rules','15 / 15'],
 ['Adversarial/boundary','Unverified rate, rate bounds, exact 5pp threshold, two-source confirmation, safety stops, rejection, PII input, output limits','24 / 24']], [131,315,72])
p('<b>Concrete defect caught:</b> an exact 5pp boundary initially entered the greater-than-5pp escalation branch due to floating-point representation. The engine was corrected with a small numeric tolerance, then rerun to a 39/39 passing result. This is an example of why adversarial tests matter.')
h('8. Metrics that still need independent evaluation')
table([['Proposed field trial metric','Method','Current status'],
 ['Unsafe automated major decisions','Count dispatch, safety, cancellation, compensation or publication actions executed by the system','None are connected; not field-tested'],
 ['Unsupported factual claims','Human reviewers audit cited facts against source rows','Not independently measured'],
 ['Correct conflict-stop behavior','Blind synthetic cases with contradictory timestamps/units','Basic functionality tested'],
 ['False alert / missed-risk rates','Expert-labeled novel scenarios with agreed criteria','Not yet measured'],
 ['Time to first actionable check','Compare human triage with/without tool on matched cases','Not yet measured']], [147,258,113])
S.append(PageBreak())

h('9. Risk card and mitigations')
table([['Risk','Potential impact','Required control'],
 ['Overconfident classification','Staff could overreact or miss a disruption','Use indeterminate stop, uncertainty qualifier and human review'],
 ['Incomparable time windows','False numeric anomaly from hourly/monthly rates','Explicit comparability confirmation gate'],
 ['False weather causation','Unjustified explanation and action','Separate forecasts, hypotheses and confirmed flight data'],
 ['Data conflict / staleness','Inconsistent assessment','Source reconciliation and timestamp review before action'],
 ['Passenger misinformation','Incorrect published delay or recovery information','Draft-only language and mandatory human approval'],
 ['Privacy leakage','Passenger/employee identifiers in logs','Reject common PII patterns, use synthetic data only; production safeguards needed'],
 ['Keyword or category failure','Unseen aviation nuance incorrectly categorized','Disclose limited domain understanding; further expert testing'],
 ['Human rejection mishandled','Original advice could be erased','Session audit retains original risk and reviewer reason']], [131,170,217])
h('10. Proposed staged rollout')
table([['Timing','Work','Exit condition'],
 ['Week 1','Approve input definitions, source ownership, reviewer roles and privacy policy','Operations and data owners sign off'],
 ['Weeks 2-3','At least 50 independent unseen simulated exercises with two aviation reviewers','Safety action count = 0; source-backed claims audited'],
 ['Weeks 4-5','Controlled human-only shadow workflow; time and error analysis','No critical unresolved privacy or safety failure'],
 ['Week 6','Review evidence to decide whether more integration research is warranted','Written go/no-go decision by qualified leads']], [73,241,204])
p('This timeline is only a proposal. Nothing in this submission authorizes deployment on real operational data or passenger communication channels.')
S.append(PageBreak())

h('11. Reproducibility and submission contents')
p('<b>Immediate demonstration:</b> Open index.html directly. No Python, Node server or API key is needed. The five simulations and novel-case interface operate locally. A GitHub public repository containing index.html can optionally expose the app using GitHub Pages; simply viewing the HTML source on github.com does not execute the app.')
p('<b>Regenerate inputs:</b> python src/build_data.py reads source/Track3_Data_original.xlsx and writes data/simulation.json. Node tests/run_tests.mjs checks behavior and writes the reproducible test summary and five event outputs. Node src/build.mjs embeds those files and the application engine into index.html. Optional spreadsheet and PDF builders require the supplied authoring dependencies.')
p('<b>Core files:</b> index.html, README.md, src/engine.js, src/app.js, data/simulation.json, tests/run_tests.mjs, tests/ui_smoke.mjs, docs/Client_Presentation.pptx, docs/Completed_Track3_English.xlsx, this report, the thumbnail asset and unmodified original competition materials.')
p('<b>Governance:</b> All source files and generated outcomes are simulation-only. Unit tests are implementation-authored. The system has no authentication, deployment controls or independently verified aviation performance. User-entered data should remain synthetic and should not include personally identifying information.')
h('12. Next research tasks')
p('1. Independent expert labels for at least 50 new scenarios. 2. Timestamp and denominator-specific anomaly detection. 3. Actual flight rotation and airport capacity modeling under authorized data access. 4. Error analysis of missed risk, over-escalation and human override. 5. Secure audit storage, identity management and robust privacy filters before any operational pilot.')

doc.build(S,onFirstPage=footer,onLaterPages=footer)
print(OUT)
