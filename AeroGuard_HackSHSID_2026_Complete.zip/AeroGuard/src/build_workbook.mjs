import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook, SpreadsheetFile, FileBlob} from '@oai/artifact-tool';
const root=process.env.AEROGUARD_PROJECT_ROOT || path.resolve(path.dirname(new URL(import.meta.url).pathname),'..');
const d=JSON.parse(await fs.readFile(path.join(root,'data/simulation.json'),'utf8'));
const tests=JSON.parse(await fs.readFile(path.join(root,'data/test_summary.json'),'utf8'));
const outputs=JSON.parse(await fs.readFile(path.join(root,'data/event_outputs.json'),'utf8'));
const original=await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(root,'source/Track3_Data_original.xlsx')));
const wb=Workbook.create();
const map=Object.fromEntries([['云川国际机场','Yunchuan International Airport'],['海陵国际机场','Hailing International Airport'],['北岭机场','Beiling Airport'],['星湖机场','Xinghu Airport'],['南湾机场','Nanwan Airport'],['青岚机场','Qinglan Airport'],['临江机场','Linjiang Airport'],['高原机场','Gaoyuan Airport']]);
function sheet(name,headers,rows,widths){
 const sh=wb.worksheets.add(name);sh.showGridLines=false;sh.getRange('A1').write([headers,...rows]);
 const head=sh.getRangeByIndexes(0,0,1,headers.length);head.format.fill='#153A60';head.format.font.color='#FFFFFF';head.format.font.bold=true;head.format.rowHeight=31;
 sh.getRangeByIndexes(0,0,rows.length+1,headers.length).format.wrapText=true;sh.freezePanes.freezeRows(1);
 (widths||[]).forEach((w,i)=>sh.getRangeByIndexes(0,i,rows.length+1,1).format.columnWidth=w);
 return sh;
}
sheet('START HERE',['Topic','What the evaluator should know'],[
 ['Project','AeroGuard: Explainable Airport Disruption Assistant | HackSHSID 2026 Track 3'],
 ['Problem','Support professional airline response to weather and operational disruptions using traceable simulated evidence'],
 ['Primary deliverable','index.html: single-file offline interactive scenario and decision-support prototype'],
 ['Coverage','8 fictional airports; 192 airport-month operating rows; 192 monthly weather rows; 5 organizer events'],
 ['Data origin','Competition organizer simulation. All airports and numerical observations are invented'],
 ['Reference metric','Scheduled-completion fraction; do not substitute departure punctuality'],
 ['Baseline','Unweighted mean of the 12 monthly 2025 scheduled-completion fractions at each airport'],
 ['Operational rule','5 percentage points below history prompts review only if current value has same metric, denominator and monthly window'],
 ['Human authority','AI never executes safety, dispatch, cancellation, maintenance, compensation or passenger publication decisions'],
 ['Verification',`${tests.passed}/${tests.total} deterministic functionality checks; not independent aviation accuracy or safety validation`],
 ['Instructions','Open index.html directly, select an event or New, verify outputs; optional Node tests under tests/'],
 ['Further testing needed','Blind unseen event trials; expert review; false-alarm, privacy, source-reliability and usability assessment']], [27,112]);
const baselineHeaders=['Airport','Class','Business importance','2025 passengers (10k)',...Array.from({length:12},(_,i)=>`2025 month ${i+1}`),'Average (formula)','Mean (verified)','Difference (pp)','Weather missing months'];
const baselineRows=d.airports.map(a=>[a.name,a.class,a.importance,a.passengers_10k,...a.monthly_2025.map(m=>m.completed),null,a.baseline_mean,null,a.weather_missing_months]);
const base=sheet('2025 Baselines',baselineHeaders,baselineRows,[33,13,17,20,...Array(12).fill(17),20,19,20,24]);
for(let i=0;i<baselineRows.length;i++){const row=i+2;base.getRange(`Q${row}`).formulas=[[`=AVERAGE(E${row}:P${row})`]];base.getRange(`S${row}`).formulas=[[`=(Q${row}-R${row})*100`]];}
base.getRange('E2:R9').setNumberFormat('0.00%');base.getRange('S2:S9').setNumberFormat('0.0000');
const sourceRows=original.worksheets.getItem('01_机场月度运行基线').getRange('A2:L193').values;
sheet('Source Operating Data',['Year','Month','Airport','Airport class','Scheduled-completion fraction','Departure punctuality fraction','Peer-class completion fraction','Historical rolling mean','Deviation from rolling mean (pp)','Source ID'],sourceRows.map(r=>[r[0],r[1],map[r[2]],{'大型机场':'Large','中型机场':'Medium','小型机场':'Small'}[r[3]],r[4],r[5],r[6],r[7],r[8],r[10]]),[10,10,34,17,24,25,27,21,31,16]);
sheet('Scenarios',['ID','Name','Time','Airport','Weather narrative','Operating narrative','Weather risk','Operating pressure','Source conflict','Independent sources declared','Unknowns'],d.events.map(e=>[e.id,e.name,e.time,e.airport,e.weather,e.operations,e.weatherRisk,e.pressure,e.conflict?'Yes':'No',e.independentSources,e.unknowns]),[13,34,20,35,62,75,18,20,17,23,76]);
sheet('Decisions',['Event ID','Risk','Confidence','Evidence','Assumptions','Unknown information','First action','Further actions','Escalation','Rules fired','Operations message','Airport coordination message','Passenger draft','Status'],d.events.map(e=>{const x=outputs[e.id];return[e.id,x.risk,x.confidence,x.facts.map(f=>`${f.statement} [${f.source}]`).join('\n'),x.assumptions.join('\n'),x.gaps.join('\n'),x.steps[0],x.steps.slice(1).join('\n'),x.escalation,x.rules.join('; '),x.messages.operations,x.messages.airport,x.messages.passengers,'Human review required']}),[16,18,28,98,66,70,65,75,77,38,90,90,102,26]);
const ruleRows=[
 ['RULE001','Insufficient information','Missing or contradictory evidence','Verify sources, timestamps and definitions','Suspend firm conclusions'],
 ['RULE002','Weather risk','Moderate/high weather without official status','Check updated weather and airport capacity','Monitor and prepare drafts'],
 ['RULE003','Unusual operating decrease','Comparable verified rate >5pp below 12-month mean','Verify denominator and peer data','Flag for human review'],
 ['RULE004','Persistent operations pressure','Earlier decline and concentrated later schedule','Check rotations, gates and handling','Prioritize checks in time order'],
 ['RULE005','Passenger communication','Risk without confirmed flight status','Verify publishable facts and update times','Draft only, require approval'],
 ['RULE006','Human feedback','Operator rejects or changes advice','Record objections and new evidence','Preserve original and reassess'],
 ['RULE007','Major operational decisions','Cancellation, release, dispatch, maintenance, compensation','Refer to authorized personnel','No automated execution'],
 ['RULE008','High-risk escalation','Independent compound risks expanding impact','Require corroboration','Recommend lead review'],
 ['RULE009','Evidence citations','Numerical claim or formal status','Check source ID and time window','Cite each important fact'],
 ['RULE010','Simulation disclosure','Organizer synthetic input','Label all generated claims','Do not represent as real'],
 ['RULE011','Privacy','Personal data submitted','Delete or deidentify','Avoid storing sensitive information'],
 ['RULE012','Stop conditions','Unreliable source or safety problem','Suspend conclusions and route to human','No definite major-action advice']];
sheet('Rules',['Rule ID','Subject','Trigger','Verification','Allowed response'],ruleRows,[16,34,67,76,73]);
sheet('Test Results',['Test ID','Check','Result','Evidence type','Important limitation'],tests.cases.map(t=>[t.id,t.label,t.pass?'PASS':'FAIL',t.id.startsWith('TEST')?'Organizer-aligned contract':'Additional boundary or negative case','Automated deterministic checks; not independent operational validation']),[15,73,18,32,80]);
sheet('Human Feedback',['Event ID','Organizer example','Rationale','Action','Status'],[
 ['EVT001','Accepted','Check airport handling capacity and retain passenger draft','Monitor and verify first','Organizer-simulated example'],
 ['EVT004','Modified','Original passenger wording could imply confirmed delay','Clarify warning vs formal status','Organizer-simulated example'],
 ['EVT005','Rejected','Operations staff report adequate resources','Continue monitoring, record verified evidence','Organizer-simulated example']],[18,20,86,85,38]);
sheet('Data Quality',['Issue ID','Fact','Consequence','Mitigation'],[
 ['DQ001','All airports, localities, event narratives and numeric records are fictional','Cannot generalize accuracy to real airports','Label all inputs and outputs as simulation'],
 ['DQ002','Four weather records are flagged missing in the 192-row source','Historical meteorology incomplete','Preserve missing flag and avoid inference'],
 ['DQ003','EVT003 has contradictory source claims with timestamps 40 minutes apart','Unreliable operational state','Indeterminate and human source reconciliation'],
 ['DQ004','Hailing July/August 2025 contains organizer-designed anomalies','Synthetic outliers can exaggerate variance','Describe engineered test data, do not treat as field evidence']],[20,85,77,84]);
sheet('Submission Checklist',['ID','Item','File','Status'],[
 ['D01','Client presentation','docs/Client_Presentation.pptx','Prepared; add team details'],
 ['D02','Working assistant prototype','index.html','Offline interactive demo tested'],
 ['D03','Testing evidence','docs/Technical_Report.pdf + data/test_summary.json','39 function tests; independent testing pending'],
 ['D04','Data and rules','This workbook; source/Track3_Data_original.xlsx','Simulation provenance preserved'],
 ['D05','Human feedback','Human Feedback sheet and exported review JSON','Organizer example plus interactive feedback'],
 ['D06','Risk card','docs/Technical_Report.pdf','Prepared'],
 ['D07','Roadmap','docs/Technical_Report.pdf','Proposal only'],
 ['D08','Reproduction package','README.md + tests/run_tests.mjs + source files','Prepared']],[13,37,72,69]);
const output=await SpreadsheetFile.exportXlsx(wb);
await output.save(path.join(root,'docs/Completed_Track3_English.xlsx'));
console.log('Wrote English workbook');
