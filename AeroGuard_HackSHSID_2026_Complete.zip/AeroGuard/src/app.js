(function () {
  'use strict';
  const data = window.AeroGuardData;
  const engine = window.AeroGuardEngine;
  const $ = id => document.getElementById(id);
  let current = null;
  const audit = [];
  const choices = data.events;
  const set = (id, value) => { $(id).textContent = value ?? ''; };
  const option = (label, value) => { const o = document.createElement('option'); o.value = value; o.textContent = label; return o; };
  const empty = element => { while (element.firstChild) element.removeChild(element.firstChild); };
  const para = text => { const e = document.createElement('p'); e.textContent = text; e.className = 'body-text'; return e; };

  function init() {
    for (const event of choices) $('scenario').appendChild(option(`${event.id} · ${event.name}`, event.id));
    $('scenario').appendChild(option('NEW · Create an unseen incident', 'NEW'));
    for (const airport of data.airports) $('airport').appendChild(option(airport.name, airport.name));
    $('scenario').addEventListener('change', () => { loadScenario(); evaluate(); });
    $('airport').addEventListener('change', evaluate);
    $('analyze').addEventListener('click', evaluate);
    $('newScenario').addEventListener('click', () => { $('scenario').value = 'NEW'; loadScenario(); evaluate(); });
    $('applyReview').addEventListener('click', applyReview);
    $('downloadAudit').addEventListener('click', downloadAudit);
    $('testCount').textContent = `${data.self_tests.passed}/${data.self_tests.total} passed`;
    $('testProgress').style.width = `${Math.round(100 * data.self_tests.passed / data.self_tests.total)}%`;
    $('testDetails').textContent = data.self_tests.description;
    $('scenario').value = choices[0].id;
    loadScenario();
    evaluate();
  }

  function loadScenario() {
    const selected = choices.find(e => e.id === $('scenario').value);
    $('airport').value = selected?.airport || data.airports[0].name;
    $('incidentName').value = selected?.name || '';
    $('weatherRisk').value = selected?.weatherRisk || 'Unknown';
    $('pressure').value = selected?.pressure || 'Unknown';
    $('weather').value = selected?.weather || '';
    $('operations').value = selected?.operations || '';
    $('unknowns').value = selected?.unknowns || '';
    $('sourceStatus').value = 'Unknown';
    $('independentSources').value = String(selected?.independentSources || 0);
    $('conflict').checked = selected?.conflict || false;
    $('safetyConcern').checked = false;
    $('currentRate').value = '';
    $('comparableRateVerified').checked = false;
    $('reviewDecision').value = '';
    $('reviewReason').value = '';
    $('resourcesVerified').checked = false;
  }

  function readInput() {
    const selected = choices.find(e => e.id === $('scenario').value);
    const enteredRate = $('currentRate').value.trim();
    const numeric = enteredRate === '' ? null : Number(enteredRate);
    return {
      id: selected?.id || 'NEW', name: $('incidentName').value.trim(), airport: $('airport').value,
      time: selected?.time || 'New scenario time not specified', weather: $('weather').value,
      operations: $('operations').value, unknowns: $('unknowns').value,
      weatherRisk: $('weatherRisk').value, pressure: $('pressure').value,
      sourceStatus: $('sourceStatus').value, independentSources: Number($('independentSources').value),
      conflict: $('conflict').checked, safetyConcern: $('safetyConcern').checked,
      currentRate: numeric, comparableRateVerified: $('comparableRateVerified').checked,
      officialStatusVerified: false,
    };
  }

  function showError(errors) {
    $('errors').style.display = errors.length ? 'block' : 'none';
    $('errors').textContent = errors.join('\n');
  }

  function evaluate() {
    const input = readInput();
    const result = engine.analyze(input, data);
    if (!result.ok) { showError(result.errors); return; }
    showError([]);
    current = result;
    audit.push({ kind: 'assessment', time: new Date().toISOString(), input, output: result });
    render(result);
  }

  function applyReview() {
    const feedback = {
      decision: $('reviewDecision').value,
      reason: $('reviewReason').value.trim(),
      resourcesVerified: $('resourcesVerified').checked,
    };
    if (!feedback.decision) { showError(['Choose Accept, Modify or Reject before applying a human review.']); return; }
    if (!feedback.reason) { showError(['A reason is required to create an auditable review record.']); return; }
    const input = readInput();
    const result = engine.analyze(input, data, feedback);
    if (!result.ok) { showError(result.errors); return; }
    showError([]);
    current = result;
    audit.push({ kind: 'human-review', time: new Date().toISOString(), input, feedback, output: result });
    render(result);
  }

  function riskClass(risk) {
    return ({Low:'risk-low',Medium:'risk-medium',High:'risk-high',Indeterminate:'risk-indeterminate'})[risk] || '';
  }

  function render(result) {
    set('riskValue', result.risk);
    $('riskValue').className = `value ${riskClass(result.risk)}`;
    set('riskSub', `Rule-based ${result.sourceKind.toLowerCase()} assessment`);
    set('confidenceValue', result.confidence);
    set('baselineValue', result.calculation.baseline === null ? 'N/A' : `${(result.calculation.baseline * 100).toFixed(2)}%`);
    set('decisionText', result.decision);
    set('calcNote', result.calculation.deviationPp === null
      ? 'No numeric anomaly claim was made. Only verified comparable monthly rates are eligible for a 5 percentage-point check.'
      : `Verified comparable rate: ${(result.calculation.rate * 100).toFixed(2)}%. Difference from baseline: ${result.calculation.deviationPp.toFixed(2)} percentage points.`);
    set('reviewStatus', result.review ? `HUMAN ${result.review.decision.toUpperCase()}` : 'HUMAN REVIEW REQUIRED');
    $('reviewBanner').style.display = result.review ? 'block' : 'none';
    set('reviewBanner', result.review ? `Original risk: ${result.review.originalRisk}. Reviewer ${result.review.decision}: ${result.review.reason}. Revised risk: ${result.risk}.` : '');
    const evidence = $('factList'); empty(evidence);
    result.facts.forEach(item => { const node = document.createElement('div'); node.className = 'fact';
      const body = document.createElement('span'); body.textContent = item.statement;
      const label = document.createElement('small'); label.textContent = `Source: ${item.source}`;
      node.appendChild(body); node.appendChild(label); evidence.appendChild(node); });
    const tags = $('ruleTags'); empty(tags);
    result.rules.forEach(rule => { const tag = document.createElement('span'); tag.className = 'tag'; tag.textContent = rule; tags.appendChild(tag); });
    renderList('assumptionList', result.assumptions, 'No causal assumptions required.');
    renderList('gapList', result.gaps, 'No additional gaps specified.');
    const steps = $('actionList'); empty(steps);
    result.steps.forEach(step => { const li = document.createElement('li'); li.textContent = step; steps.appendChild(li); });
    set('escalationText', result.escalation);
    set('humanOnly', result.humanOnly);
    set('opsMessage', result.messages.operations);
    set('airportMessage', result.messages.airport);
    set('passengerMessage', result.messages.passengers);
    drawChart(result.airport);
  }

  function renderList(id, values, fallback) {
    const list = $(id); empty(list);
    if (!values.length) list.appendChild(para(fallback));
    else values.forEach(v => list.appendChild(para(`• ${v}`)));
  }

  function drawChart(airportName) {
    const svg = $('historyChart'); empty(svg);
    const airport = data.airports.find(a => a.name === airportName);
    if (!airport) { set('historyRange', 'No history available'); return; }
    const points = airport.monthly_2025;
    const marginX = 27, width = 600, top = 15, height = 86;
    const yMin = Math.max(0, Math.floor((Math.min(...points.map(p => p.completed), airport.baseline_mean) - .03) * 10) / 10);
    const yMax = Math.min(1, Math.ceil((Math.max(...points.map(p => p.completed), airport.baseline_mean) + .03) * 10) / 10);
    const x = index => marginX + width * index / 11;
    const y = value => top + (yMax - value) / Math.max(.00001, yMax - yMin) * height;
    const NS='http://www.w3.org/2000/svg';
    const element=(type,attrs)=>{const e=document.createElementNS(NS,type);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,String(v));svg.appendChild(e);return e;};
    for(const level of [yMin,(yMin+yMax)/2,yMax])element('line',{x1:marginX,y1:y(level),x2:marginX+width,y2:y(level),stroke:'#31526d','stroke-width':'.7'});
    element('line',{x1:marginX,y1:y(airport.baseline_mean),x2:marginX+width,y2:y(airport.baseline_mean),stroke:'#d8bd82','stroke-width':'1.6','stroke-dasharray':'6 4'});
    const path = points.map((p,i)=>`${i?'L':'M'}${x(i).toFixed(2)},${y(p.completed).toFixed(2)}`).join(' ');
    element('path',{d:path,fill:'none',stroke:'#66d3ff','stroke-width':'2.6','stroke-linecap':'round','stroke-linejoin':'round'});
    points.forEach((p,i)=>element('circle',{cx:x(i),cy:y(p.completed),r:2.7,fill:'#80e6ff'}));
    for(const month of [1,4,7,10,12]){const t=element('text',{x:x(month-1),y:118,'text-anchor':'middle',fill:'#8baccc','font-size':10});t.textContent=String(month).padStart(2,'0');}
    set('historyRange', `2025 observed range: ${(airport.baseline_min*100).toFixed(1)}–${(airport.baseline_max*100).toFixed(1)}%`);
  }

  function downloadAudit() {
    if (!audit.length) { showError(['No assessment has been created yet.']); return; }
    const payload = {
      project: 'AeroGuard', engine: engine.version,
      disclaimer: 'Fictional simulation; automated operational actions are prohibited.',
      exportedAt: new Date().toISOString(), history: audit,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a'); link.href=url; link.download='AeroGuard_Simulation_Audit.json';
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  }

  init();
})();
