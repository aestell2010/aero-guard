import fs from 'node:fs/promises';
import path from 'node:path';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
const root=process.env.AEROGUARD_PROJECT_ROOT||path.resolve(path.dirname(new URL(import.meta.url).pathname),'..');
const data=JSON.parse(await fs.readFile(path.join(root,'data/simulation.json'),'utf8'));
const summary=JSON.parse(await fs.readFile(path.join(root,'data/test_summary.json'),'utf8'));
const pres=Presentation.create({slideSize:{width:1280,height:720}});
const C={navy:'#102D4D',ink:'#173553',blue:'#1977B4',paper:'#F7FBFE',gray:'#4A657D',pale:'#DFECF7'};
function textbox(s,txt,x,y,w,h,size=25,color=C.ink,bold=false){const shape=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{style:'solid',fill:'none',width:0}});shape.text=txt;shape.text.style={fontFamily:'Arial',fontSize:size,color,bold};return shape}
function start(title,subtitle,index){const s=pres.slides.add();s.background.fill=C.paper;textbox(s,'AEROGUARD / HACKSHSID 2026 / TRACK 3',72,37,930,28,15,C.blue,true);textbox(s,title,72,101,1120,100,43,C.navy,true);textbox(s,subtitle,75,207,1130,77,22,C.gray);textbox(s,'FICTIONAL SIMULATION ONLY  •  Human approval required for operational decisions',72,680,1000,20,12,C.gray);textbox(s,String(index).padStart(2,'0'),1163,677,55,26,15,C.gray);return s}
function trio(title,subtitle,items,index){const s=start(title,subtitle,index);let y=315;for(const [a,b] of items){textbox(s,a,79,y,325,66,26,C.blue,true);textbox(s,b,407,y,786,81,23,C.ink);y+=114;}return s}
{const s=pres.slides.add();s.background.fill=C.navy;const img=await fs.readFile(path.join(root,'assets/AeroGuard_Thumbnail.png'));s.images.add({blob:img.buffer.slice(img.byteOffset,img.byteOffset+img.byteLength),contentType:'image/png',alt:'AeroGuard airport operations concept image',fit:'cover',position:{left:0,top:0,width:1280,height:720}});textbox(s,'HackSHSID 2026  •  Accenture Track 3',68,642,870,40,22,'#FFFFFF',true);}
trio('The airline disruption problem','Operational information is frequently incomplete precisely when action is urgent',[
 ['Early warning','Airport-level weather and operating pressure may precede downstream flight problems.'],
 ['Conflicting evidence','Late updates and incompatible reporting windows make confident claims unsafe.'],
 ['Human coordination','Operations, airport staff and passengers need different information.']],2);
trio('AeroGuard decision support','A traceable rule engine for synthetic events and new user-entered scenarios',[
 ['Context','Compare each fictional airport against its own 2025 monthly baseline.'],
 ['Reasoning','Separate observed inputs, hypotheses, missing data and triggered rules.'],
 ['Response','Recommend a verification sequence and three reviewable message drafts.']],3);
{const s=start('Eight airport-specific baselines','Historical scheduled-completion means differ across fictional airports; values are unweighted monthly averages',4);const a=data.airports;const chart=s.charts.add('bar',{position:{left:95,top:300,width:1080,height:323},categories:a.map(x=>x.name.replace(' International Airport',' Intl').replace(' Airport','')),series:[{name:'2025 monthly mean (%)',values:a.map(x=>Math.round(x.baseline_mean*10000)/100),fill:'#317FB8'}],hasLegend:false,dataLabels:{showValue:true,position:'outEnd'},xAxis:{},yAxis:{majorGridlines:{style:'solid',fill:'#D6E3F0',width:1}}});textbox(s,'Source: SIM-BASE · 12 monthly observations per airport · 2025',90,634,1000,24,14,C.gray);}
trio('Rules that protect against overconfidence','No direct flight forecasts or safety decisions are made from monthly aggregates',[
 ['Verify comparability','A current rate is only compared after matching metric, denominator and monthly time window.'],
 ['Stop on uncertainty','Conflicting/unreliable sources or safety issues return Indeterminate.'],
 ['Escalate with evidence','A high-risk recommendation needs strong verified signals and human review.']],5);
{const s=start('Five organizer scenarios','Different inputs produce distinct checks and clearly qualified risk outcomes',6);const rows=[['EVT001','Medium','Heavy rain and concentrated schedules'],['EVT002','Medium','Operating pressure with gate changes'],['EVT003','Indeterminate','Conflicting sources updated 40 minutes apart'],['EVT004','Medium','Passenger draft before a formal notice'],['EVT005','Medium','Reviewer objection and resource verification']];let y=310;for(const [id,risk,note] of rows){textbox(s,id,88,y,135,38,20,C.blue,true);textbox(s,risk,251,y,208,35,20,C.ink,true);textbox(s,note,490,y,695,53,21,C.ink);y+=68;}}
trio('New incidents and expert feedback','A new incident is evaluated from entered information, with the original assessment retained',[
 ['Unseen inputs','A sixth scenario option accepts a new event at any of the eight airports.'],
 ['Human review','Accept, modify or reject; require rationale and preserve the earlier risk.'],
 ['Audit export','Download a time-ordered JSON record of input, output and reviewer feedback.']],7);
trio(`${summary.passed}/${summary.total} automated checks passed`,'Functional checks include the organizer prompts and additional numeric/adversarial boundary cases',[
 ['15 organizer checks','Source conflict, evidence references, missing information, human approval and audience drafts.'],
 ['24 additional checks','Comparability gates, exact 5 pp threshold, unsafe inputs, safety stops and reviewer overrides.'],
 ['Claim boundary','Implementation-authored tests cannot prove flight prediction accuracy or real-world safety.']],8);
trio('Known limitations and safety controls','A useful research prototype still requires independent expert validation',[
 ['Synthetic only','Every airport and operating number comes from the organizer simulation.'],
 ['No automated actions','No dispatch, cancellation, maintenance, compensation or message publication API.'],
 ['Further safeguards','Source authentication, stronger privacy handling and expert scenario labels remain future work.']],9);
trio('The next six weeks','Proposed supervised research roadmap before any operational deployment decision',[
 ['Week 1','Approve metric definitions, source ownership and reviewer responsibilities.'],
 ['Weeks 2–3','Run 50+ genuinely unseen blind scenarios with independent expert review.'],
 ['Weeks 4–6','Shadow-test usability and errors; decide whether controlled integration research is justified.']],10);
const draft=path.join(root,'docs/Presentation_Draft.pptx');
await (await PresentationFile.exportPptx(pres)).save(draft);
const preview=path.join(root,'docs/previews');await fs.mkdir(preview,{recursive:true});
for(const [index,slide] of pres.slides.items.entries()){
  const img=await pres.export({slide,format:'png',scale:.6});
  await fs.writeFile(path.join(preview,`slide-${String(index+1).padStart(2,'0')}.png`),new Uint8Array(await img.arrayBuffer()));
}
console.log('Exported',draft);
