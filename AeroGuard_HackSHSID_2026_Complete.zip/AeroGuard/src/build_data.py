"""Extract the organizer's fictional airport dataset into an English, auditable JSON snapshot.

Run from the repository root: python src/build_data.py
Requires openpyxl. Nothing is downloaded and no live airline data is used.
"""
from __future__ import annotations
import json, statistics
from pathlib import Path
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "source" / "Track3_Data_original.xlsx"
OUTPUT = ROOT / "data" / "simulation.json"
NAME = {
    "云川国际机场": "Yunchuan International Airport", "海陵国际机场": "Hailing International Airport",
    "北岭机场": "Beiling Airport", "星湖机场": "Xinghu Airport", "南湾机场": "Nanwan Airport",
    "青岚机场": "Qinglan Airport", "临江机场": "Linjiang Airport", "高原机场": "Gaoyuan Airport",
}


def records(sheet):
    itr = iter(sheet.values)
    head = next(itr)
    return [dict(zip(head, r)) for r in itr]


def main():
    w = load_workbook(INPUT, data_only=True, read_only=True)
    baseline = records(w["01_机场月度运行基线"])
    scale = records(w["02_机场年度规模"])
    weather = records(w["03_机场天气月度"])
    if len(baseline) != 192 or len(weather) != 192 or len(scale) != 16:
        raise ValueError("Unexpected source row counts")
    airports = []
    for original, english in NAME.items():
        history = sorted([r for r in baseline if r["机场名称"] == original], key=lambda r: (r["年份"], r["月份"]))
        if len(history) != 24 or len({(r['年份'], r['月份']) for r in history}) != 24:
            raise ValueError(f"Missing or duplicate month for {english}")
        for r in history:
            for col in ("按计划完成航班的比例", "机场放行正常比例", "同类机场平均比例"):
                if not isinstance(r[col], (int, float)) or not 0 <= r[col] <= 1:
                    raise ValueError(f"Invalid rate for {english} {r['年份']}/{r['月份']}")
        y2025 = [r for r in history if r["年份"] == 2025]
        rates = [r["按计划完成航班的比例"] for r in y2025]
        size = next(r for r in scale if r["年份"] == 2025 and r["机场名称"] == original)
        bad_weather = [r for r in weather if r["机场名称"] == original and r["是否缺少数据"] == "是"]
        airports.append({
            "name": english, "class": {"大型机场": "Large", "中型机场": "Medium", "小型机场": "Small"}[size["机场分类"]],
            "importance": {"高": "High", "中": "Medium", "低": "Low"}[size["航空公司业务重要程度"]],
            "passengers_10k": size["旅客吞吐量（万人次）"],
            "history_months": len(history), "baseline_n": 12,
            "baseline_mean": round(statistics.mean(rates), 6),
            "baseline_sd_pp": round(100 * statistics.stdev(rates), 3),
            "baseline_min": min(rates), "baseline_max": max(rates),
            "weather_missing_months": len(bad_weather),
            "monthly_2025": [{"month": r["月份"], "completed": r["按计划完成航班的比例"],
                              "departure": r["机场放行正常比例"], "peer": r["同类机场平均比例"]} for r in y2025],
            "source_ids": ["SIM-BASE", "SIM-SCALE", "SIM-WEATHER"],
        })
    events = [
        {"id": "EVT001", "name": "Heavy rain and gust forecast", "time": "Day 4, 14:00", "airport": "Hailing International Airport", "weather": "Heavy rain and gusts forecast for the next six hours", "operations": "Morning near normal; concentrated afternoon flights", "weatherRisk": "High", "pressure": "Medium", "conflict": False, "independentSources": 1, "unknowns": "Flight rotations, crew status, ground capacity, and official flight status"},
        {"id": "EVT002", "name": "Sustained operating pressure", "time": "Day 4, 18:30", "airport": "Beiling Airport", "weather": "No material deterioration observed", "operations": "Morning scheduled-completion proportion declined; gate changes are frequent; evening flights remain concentrated", "weatherRisk": "None", "pressure": "High", "conflict": False, "independentSources": 1, "unknowns": "Exact affected flights, gate availability, inbound aircraft locations"},
        {"id": "EVT003", "name": "Conflicting reports", "time": "Day 6, 10:00", "airport": "Yunchuan International Airport", "weather": "Stable weather", "operations": "Source A indicates normal operations, source B indicates a substantial decline. Reports differ by 40 minutes", "weatherRisk": "None", "pressure": "Unknown", "conflict": True, "independentSources": 0, "unknowns": "Verified source owner, reporting definitions, source recency"},
        {"id": "EVT004", "name": "Passenger communication preparation", "time": "Day 6, 15:00", "airport": "Nanwan Airport", "weather": "Brief thunderstorms expected this evening", "operations": "No official delay notification", "weatherRisk": "Medium", "pressure": "None", "conflict": False, "independentSources": 1, "unknowns": "Official flight status, affected passengers, estimated recovery"},
        {"id": "EVT005", "name": "Human rejection and reassessment", "time": "Day 6, 20:00", "airport": "Gaoyuan Airport", "weather": "Low temperature and stronger winds", "operations": "Prior AI advice suggested a high-risk escalation; operations staff claim capacity is adequate", "weatherRisk": "Medium", "pressure": "Unknown", "conflict": False, "independentSources": 1, "unknowns": "Verified on-site resources and operator rationale"},
    ]
    result = {
        "project": "AeroGuard", "source_kind": "Organizer-generated fictional simulation",
        "period": "2024-2025", "baseline_period": "January-December 2025",
        "sources": {"SIM-BASE": "Organizer monthly operating data", "SIM-SCALE": "Organizer airport annual size table", "SIM-WEATHER": "Organizer monthly weather data", "SIM-EVENT": "Organizer incident descriptions", "RULE": "Organizer operational rulebook"},
        "data_quality": {"weather_missing_rows": sum(r["是否缺少数据"] == "是" for r in weather),
                         "designed_anomaly": "Hailing International Airport, July-August 2025",
                         "known_source_conflict": "EVT003"},
        "airports": airports, "events": events,
    }
    OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Validated {len(airports)} airports; {len(baseline)} operating records; {len(weather)} weather records; {len(events)} events.")


if __name__ == "__main__":
    main()
