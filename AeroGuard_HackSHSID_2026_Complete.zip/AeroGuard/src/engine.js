/* AeroGuard v3.0 - deterministic, explainable airport triage for fictional scenarios.
   Pure logic: no DOM, network, hidden model calls or real operational commands. */
(function (root) {
  'use strict';

  const WEATHER = ['None', 'Medium', 'High', 'Unknown'];
  const PRESSURE = ['None', 'Medium', 'High', 'Unknown'];
  const STOP = 'Indeterminate';
  const uniq = values => [...new Set(values)];
  const pct = value => `${(value * 100).toFixed(2)}%`;
  const pp = value => `${value < 0 ? '' : '+'}${value.toFixed(2)} pp`;
  function text(value) { return String(value ?? '').trim(); }

  function rejectPersonalData(input) {
    const all = [input.name, input.weather, input.operations, input.unknowns].map(text).join(' ');
    if (/\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b/i.test(all)) return 'Email addresses are not permitted in this simulation.';
    if (/\b(?:\+?\d[\s-]?){9,15}\b/.test(all)) return 'Potential telephone or identification numbers are not permitted.';
    return '';
  }

  function validate(input) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) return ['An incident object is required.'];
    const errors = [];
    if (!text(input.airport)) errors.push('Select an airport.');
    if (!WEATHER.includes(input.weatherRisk)) errors.push('Select a valid weather risk.');
    if (!PRESSURE.includes(input.pressure)) errors.push('Select a valid operating pressure.');
    if (input.currentRate !== '' && input.currentRate !== null && input.currentRate !== undefined) {
      if (typeof input.currentRate !== 'number' || !Number.isFinite(input.currentRate) || input.currentRate < 0 || input.currentRate > 1) {
        errors.push('A comparable completion rate must be a decimal between 0 and 1.');
      }
    }
    const pii = rejectPersonalData(input);
    if (pii) errors.push(pii);
    return errors;
  }

  function analyze(input, dataset, feedback = null) {
    const errors = validate(input);
    if (errors.length) return { ok: false, errors };
    const airport = dataset.airports.find(a => a.name === input.airport);
    const facts = [];
    const assumptions = [];
    const gaps = [];
    const rules = ['RULE009', 'RULE010'];
    const steps = [];
    const event = text(input.name) || 'Unseen disruption scenario';
    const weatherWarning = input.weatherRisk === 'Medium' || input.weatherRisk === 'High';
    const opsWarning = input.pressure === 'Medium' || input.pressure === 'High';
    const sourceConflict = input.conflict === true;
    const sourceUnreliable = input.sourceStatus === 'Unreliable';
    const safetyConcern = input.safetyConcern === true;
    const originalTime = text(input.time) || 'Time not provided';
    const addFact = (statement, source) => facts.push({ statement, source });
    addFact(`${event} at ${input.airport}; ${originalTime}. All data are simulated.`, 'SIM-EVENT');
    if (text(input.weather)) addFact(`Weather report: ${text(input.weather)}`, 'SIM-EVENT');
    if (text(input.operations)) addFact(`Operational report: ${text(input.operations)}`, 'SIM-EVENT');
    if (airport) {
      addFact(`2025 monthly completion baseline: ${pct(airport.baseline_mean)} (12 monthly observations, unweighted).`, 'SIM-BASE');
      addFact(`Airport importance: ${airport.importance}; 2025 passenger volume: ${airport.passengers_10k} ten-thousands.`, 'SIM-SCALE');
      if (airport.weather_missing_months) gaps.push(`${airport.weather_missing_months} historical monthly weather value(s) are flagged missing; this does not determine today's weather.`);
    } else {
      gaps.push('No airport-specific historical baseline is available.');
    }
    if (text(input.unknowns)) gaps.push(text(input.unknowns));
    if (input.weatherRisk === 'Unknown') gaps.push('Weather risk has not been classified by a verified source.');
    if (input.pressure === 'Unknown') gaps.push('Operational pressure has not been assessed with sufficient detail.');
    if (input.sourceStatus !== 'Verified') gaps.push('Source currency or reliability is not fully verified.');
    if (weatherWarning) {
      addFact(`User-provided weather risk: ${input.weatherRisk} (unverified scenario classification).`, 'SIM-EVENT');
      assumptions.push('Adverse weather may restrict capacity; individual flight delays have not been established.');
      rules.push('RULE002');
    }
    if (opsWarning) {
      addFact(`User-provided operational pressure: ${input.pressure} (simulated input).`, 'SIM-EVENT');
      assumptions.push('Earlier operational pressure may affect subsequent flights; the scope is unknown.');
      rules.push('RULE004');
    }
    const suppliedRate = input.currentRate !== '' && input.currentRate !== null && input.currentRate !== undefined;
    let departureGap = null;
    if (suppliedRate && airport) {
      if (input.comparableRateVerified === true) {
        departureGap = 100 * (input.currentRate - airport.baseline_mean);
        addFact(`Verified comparable scheduled-completion rate ${pct(input.currentRate)}; difference from 2025 mean ${pp(departureGap)}.`, 'SIM-EVENT + SIM-BASE');
        rules.push('RULE003');
      } else {
        gaps.push('A current rate was entered but was NOT compared: matched metric definition, denominator and monthly time window were not verified.');
      }
    }
    let risk = weatherWarning || opsWarning ? 'Medium' : 'Low';
    let confidence = 'Provisional';
    let decision = 'Monitor and verify. No flight-status conclusion is available.';
    const corroborated = Number.isInteger(input.independentSources) && input.independentSources >= 2;
    if (corroborated) confidence = 'Corroborated signals (user declared)';
    if (departureGap !== null && departureGap < -5 - 1e-8) {
      if (weatherWarning || opsWarning) risk = 'High';
      else risk = 'Medium';
      decision = 'A comparable metric is more than 5 percentage points below local history; confirm the anomaly.';
    }
    if (input.weatherRisk === 'High' && input.pressure === 'High' && corroborated) {
      risk = 'High';
      decision = 'Two declared independent signals support a proposed high-risk escalation review.';
      rules.push('RULE008');
    }
    if (sourceConflict || sourceUnreliable || !airport || safetyConcern) {
      risk = STOP;
      confidence = 'Insufficient information';
      decision = 'Stop firm operational conclusions and escalate for human source/safety review.';
      rules.push('RULE001', 'RULE012');
      if (sourceConflict) gaps.push('Two reported sources conflict; timestamps, definitions and ownership must be reconciled.');
      if (sourceUnreliable) gaps.push('Source reliability is explicitly marked unreliable.');
      if (safetyConcern) gaps.push('A safety-related issue requires a qualified specialist; no automated clearance is permitted.');
    }
    if (sourceConflict || sourceUnreliable) {
      steps.push('Obtain both source originals; verify timestamps, definitions, denominators and responsible data owners.');
    } else {
      steps.push('Confirm the current airport situation, source timestamps and responsible operations contact.');
    }
    if (weatherWarning) steps.push('Request updated meteorological information and confirm airport handling constraints.');
    if (opsWarning) steps.push('Check inbound aircraft, gate allocation and ground-handling resource availability.');
    if (departureGap !== null && departureGap < -5 - 1e-8) steps.push('Validate the 5 pp historical deviation against raw records and relevant peers.');
    steps.push('Document affected flight identities and next review time only after authorized source verification.');
    if (!input.officialStatusVerified) gaps.push('No verified flight-specific delay/cancellation status was provided.');
    rules.push('RULE005', 'RULE007');
    const originalRisk = risk;
    let review = null;
    if (feedback && ['accepted', 'modified', 'rejected'].includes(feedback.decision)) {
      rules.push('RULE006');
      review = {
        decision: feedback.decision,
        reason: text(feedback.reason) || 'No explanation provided',
        resourcesVerified: feedback.resourcesVerified === true,
        originalRisk,
      };
      if (feedback.decision === 'rejected' || feedback.decision === 'modified') {
        if (feedback.resourcesVerified && risk === 'High' && !sourceConflict && !safetyConcern) {
          risk = 'Medium';
          decision = 'Reviewer evidence indicates resources may contain the risk; continue intensified monitoring.';
        } else if (!feedback.resourcesVerified) {
          risk = STOP;
          confidence = 'Awaiting reviewer evidence';
          decision = 'Do not uphold the original recommendation without verifying the reviewer objection.';
        }
      }
    }
    const escalate = safetyConcern
      ? 'Immediately refer the safety-related issue to the qualified aviation safety/operations lead.'
      : risk === 'High'
        ? 'Request operations-lead review after confirming signal independence and operational impact.'
        : risk === STOP
          ? 'Escalate source reliability or missing evidence to the operations lead before any firm conclusion.'
          : 'Escalate if verified disruption spreads, capacity falls, or a qualified specialist identifies a safety concern.';
    const operationsMessage = `[SIMULATION / INTERNAL] ${input.airport}: ${risk} triage. ${decision} Priority: ${steps[0]} Evidence references: ${uniq(facts.map(f => f.source)).join(', ')}. Human approval required for all operational decisions.`;
    const airportMessage = `[SIMULATION / COORDINATION DRAFT] Please confirm updated weather/operating reports for ${input.airport}, airport handling capacity, gate and ground-resource status, and the reporting time window. Open information gaps: ${gaps.slice(0, 3).join('; ')}.`;
    const passengerMessage = `[SIMULATION / PASSENGER DRAFT - NOT APPROVED FOR PUBLICATION] We are monitoring conditions that may affect operations at ${input.airport}. This assessment does not establish any delay or cancellation for an individual flight. Please verify your flight status through the airline's official channels. This draft requires human review before publication.`;
    return {
      ok: true,
      id: text(input.id) || 'NEW',
      event, airport: input.airport, scenarioTime: originalTime,
      risk, confidence, decision, originalRisk,
      facts, assumptions, gaps: uniq(gaps), rules: uniq(rules), steps, escalation: escalate,
      calculation: { baseline: airport?.baseline_mean ?? null, rate: departureGap === null ? null : input.currentRate, deviationPp: departureGap, comparable: input.comparableRateVerified === true },
      humanOnly: 'Flight release, safety, cancellation, dispatch, maintenance, compensation and passenger publication.',
      messages: { operations: operationsMessage, airport: airportMessage, passengers: passengerMessage },
      review,
      sourceKind: 'Organizers synthetic simulation',
      engineVersion: '3.0.0',
    };
  }

  root.AeroGuardEngine = { analyze, validate, WEATHER, PRESSURE, version: '3.0.0' };
})(typeof window === 'object' ? window : globalThis);
