/** Bundle source data, rules and UI into a single offline-ready, English HTML file. */
import fs from 'node:fs/promises';
import path from 'node:path';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const template = await fs.readFile(path.join(root,'src/index.template.html'),'utf8');
const engine = await fs.readFile(path.join(root,'src/engine.js'),'utf8');
const app = await fs.readFile(path.join(root,'src/app.js'),'utf8');
const data = JSON.parse(await fs.readFile(path.join(root,'data/simulation.json'),'utf8'));
let summary = { total:0, passed:0, description:'Run node tests/run_tests.mjs for the full checks.' };
try { summary=JSON.parse(await fs.readFile(path.join(root,'data/test_summary.json'),'utf8')); } catch {}
data.self_tests=summary;
const json = JSON.stringify(data).replaceAll('<','\\u003c').replaceAll('>','\\u003e');
const html = template.replace('/*__DATA__*/',`window.AeroGuardData = ${json};`)
                     .replace('/*__ENGINE__*/',engine)
                     .replace('/*__APP__*/',app);
if(html.includes('/*__DATA__*/')||html.includes('/*__ENGINE__*/')||html.includes('/*__APP__*/'))throw Error('Build marker unresolved');
await fs.writeFile(path.join(root,'index.html'),html,'utf8');
console.log(`Built index.html: ${Buffer.byteLength(html)} bytes, ${data.airports.length} airports, ${data.events.length} organizer scenarios`);
