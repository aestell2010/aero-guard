# HackSHSID form text (English)

## Title

AeroGuard: An Explainable Assistant for Airport Disruptions

## Short description (under 300 characters)

AeroGuard is an offline explainable decision-support assistant that compares fictional airport incidents with historical baselines, flags conflicting evidence, prioritizes verification, and prepares human-reviewed communication drafts.

## Track

Select **Track 3: An AI Assistant for Flight Disruptions at Key Airports** (use the official dropdown label).

## Project inspiration and description

Weather and operational disruptions can create cascading problems for an airline, especially when reports arrive late or disagree. We explored how a transparent assistant might help aviation professionals decide which facts to verify first, communicate uncertainty, and respond consistently without delegating safety-critical decisions to software.

AeroGuard is a decision-support prototype for a fictional airline. It uses organizer-provided simulated operating histories for eight airports, synthetic disruption scenarios and a rulebook that specifies verification, escalation and human-approval requirements. For each airport, the prototype calculates a historical context using twelve monthly scheduled-completion observations from 2025. It then evaluates user-provided weather and operating pressure indicators, possible source conflicts and optional comparable metrics.

Every assessment reports a risk tier, evidence with source identifiers, assumptions, information gaps, prioritized verification actions and conditions for human escalation. Contradictory or unreliable evidence produces an indeterminate result rather than a confident unsupported conclusion. A current rate is compared with history only after the user confirms matching measurement definitions, denominators and monthly time windows.

The assistant generates different drafts for airline operations personnel, airport coordination staff and passengers. It never sends notifications or makes dispatch, cancellation, maintenance or safety decisions. Human reviewers can accept, modify or reject a recommendation, supply evidence and export an auditable record that retains the original decision.

The demo supports the five provided scenarios and new user-entered incident combinations. It works entirely offline from one HTML file without an API key or server. Its decision engine is deterministic and explainable; it is not connected to a generative language model or live airport systems.

Our focus is not to claim real-world prediction accuracy from synthetic data, but to demonstrate traceable reasoning, robust handling of uncertain inputs and an explicit human-in-the-loop workflow. Independent expert review and larger blind scenario tests are essential next steps.

## Testing evidence text

The AeroGuard implementation passed **39 out of 39 predefined automated functional checks**, including 15 checks aligned with the organizer's prompts and 24 additional numerical boundary, source conflict, missing information, privacy-input and human-review checks.

The tests cover: source traceability; suspension of firm conclusions when sources conflict; separation of observed information from assumptions; no fabricated flight-specific delay status; human approval of major decisions and passenger drafts; evaluation of previously unseen incident combinations; reviewer re-assessment; invalid data bounds; and the requirement to verify metric comparability before numerical anomaly detection.

One test identified an edge case at exactly a 5-percentage-point decline, where floating-point representation initially entered the strict greater-than-5pp branch. We corrected the comparison tolerance and reran the full suite successfully. A separate JavaScript/DOM smoke test confirmed that the self-contained dashboard populates its scenario and airport controls without network access, changes the displayed result, and applies human feedback.

**Limitation:** These are developer-authored functional tests on fictional data. We have not measured independent real-world aviation prediction accuracy or operational safety. A blind evaluation by domain reviewers is proposed before any real use.

## AI statement

OpenAI's ChatGPT and image-generation tools were used extensively to assist with project planning, code creation and debugging, data-processing scripts, test design, UI development, the technical report, presentation materials and the gallery thumbnail. The AeroGuard prototype itself uses a transparent, deterministic rule-based decision engine rather than a connected generative AI model. Automated tests were authored as part of development and are not independent validation. All outputs and operational recommendations require human review before any real-world application.

## GitHub repository link

Paste the actual URL of the public repository after uploading this source folder. Do not paste a hypothetical or private URL.

## Thumbnail

Upload `assets/AeroGuard_Thumbnail.png` (PNG, under 5 MB). The gallery image is a generated conceptual illustration, not a screenshot or representation of a real airline control room.
